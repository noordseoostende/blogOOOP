<?php

class Post extends Db_object
{
    public $id;
    public $title;
    public $description;
    public $short_description;

    /**methodes**/

    public static function find_all_posts(){

        return self::find_this_query("SELECT * FROM posts");
        /*    global $database;
            $result = $database->query("SELECT * FROM users");
            return $result;*/
    }
    public static function find_posts_by_id($post_id){
        $result = self::find_this_query("SELECT * FROM posts WHERE id=$post_id LIMIT 1");
        return !empty($result) ? array_shift($result) : false;
    }

}