<!-- Footer -->
.contain
<footer class=" py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">2019-2020-2021</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
